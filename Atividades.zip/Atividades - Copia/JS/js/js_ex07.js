var cont
var resposta

cont=0

while(cont<10)
{
    alert("como deixar o usuário louco com while em "+cont)
    cont++
}

for(cont = 0; cont<10; cont++){
    alert("como deixar o usuário louco com while em "+cont )

}
do{
    resposta=prompt("Prosseguir?")
}while(resposta=="sim")