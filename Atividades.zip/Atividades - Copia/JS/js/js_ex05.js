var n1, n2

n1=parseInt(prompt("Entr com um valor"))
n2=parseInt(prompt("Entr com outro valor"))

if(n1<n2){
    alert(n1+" É menor que "+n2)
}
else if(n1>n2){
        alert(n1+" É maior que "+n2)
        }
        else{
            alert(n1+" É igual a "+n2)
        }
