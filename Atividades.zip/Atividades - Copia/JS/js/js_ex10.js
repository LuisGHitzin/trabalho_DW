var v=[4,8,7,6]

//alert(v)

V[1]=20
//alert(v[2])

var lista
lista=["Zeca", 1880, "Rua Pedro Keppe", "Irati" , "PR" , 80.5, true]
alert(lista)