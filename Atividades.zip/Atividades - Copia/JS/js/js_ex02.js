var frase, n1, n2, soma

frase="Aqui temos uma String"
alert(frase)

n1=3
n2=14.5

soma=n1+n2

alert(soma)
document.write("<h2>"+soma+"</h2>")

n1=prompt("Entre com um valor")
n2=prompt("Entre com um valor")
soma=parseInt(n1)+parseInt(n2)
alert("O resultado da soma é "+soma)
document.write("<h2>"+soma+"</h2>")
